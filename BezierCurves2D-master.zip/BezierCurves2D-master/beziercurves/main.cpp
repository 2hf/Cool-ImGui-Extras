#include "application.h"

/*
The main function
@param int argc
@param char ** argv
*/
int main(int argc, char ** argv)
{
	// Run the Bezier Curve application
	Application::Run(argc, argv);
	return 0;
}
