#!/bin/sh

# Needs https://github.com/ocornut/imgui/blob/master/misc/fonts/binary_to_compressed_c.cpp

binary_to_compressed_c cft.ttf CodingFontTobi > ../CodingFontTobi.inl
binary_to_compressed_c Cousine-BoldItalic.ttf CousineBoldItalic > ../CousineBoldItalic.inl
binary_to_compressed_c Cousine-Bold.ttf CousineBold > ../CousineBold.inl
binary_to_compressed_c Cousine-Italic.ttf CousineItalic > ../CousineItalic.inl
binary_to_compressed_c Cousine-Regular.ttf CousineRegular > ../CousineRegular.inl
binary_to_compressed_c Crisp.ttf Crisp > ../Crisp.inl
binary_to_compressed_c DroidSans-Bold.ttf DroidSansBold > ../DroidSansBold.inl
binary_to_compressed_c DroidSans.ttf DroidSans > ../DroidSans.inl
binary_to_compressed_c fa-brands-400.ttf FontAwesome5Brands400 > ../FontAwesome5Brands400.inl
binary_to_compressed_c fa-regular-400.ttf FontAwesome5Regular400 > ../FontAwesome5Regular400.inl
binary_to_compressed_c fa-solid-900.ttf FontAwesome5Solid900 > ../FontAwesome5Solid900.inl
binary_to_compressed_c fontawesome-webfont.ttf FontAwesome4 > ../FontAwesome4.inl
binary_to_compressed_c forkawesome-webfont.ttf ForkAwesome > ../ForkAwesome.inl
binary_to_compressed_c ionicons.ttf Ionicons > ../Ionicons.inl
binary_to_compressed_c Karla-BoldItalic.ttf KarlaBoldItalic > ../KarlaBoldItalic.inl
binary_to_compressed_c Karla-Bold.ttf KarlaBold > ../KarlaBold.inl
binary_to_compressed_c Karla-Italic.ttf KarlaItalic > ../KarlaItalic.inl
binary_to_compressed_c Karla-Regular.ttf KarlaRegular > ../KarlaRegular.inl
binary_to_compressed_c kenney-icon-font.ttf KenneyIcons > ../KenneyIcons.inl
binary_to_compressed_c materialdesignicons-webfont.ttf MaterialDesign > ../MaterialDesign.inl
binary_to_compressed_c MaterialIcons-Regular.ttf GoogleMaterialDesign > ../GoogleMaterialDesign.inl
binary_to_compressed_c PixelCarnageMono.ttf PixelCarnageMono > ../PixelCarnageMono.inl
binary_to_compressed_c ProggyCleanSZBP.ttf ProggyCleanSZBP > ../ProggyCleanSZBP.inl
binary_to_compressed_c ProggyCleanSZ.ttf ProggyCleanSZ > ../ProggyCleanSZ.inl
binary_to_compressed_c ProggyClean.ttf ProggyClean > ../ProggyClean.inl
binary_to_compressed_c ProggySmall.ttf ProggySmall > ../ProggySmall.inl
binary_to_compressed_c ProggySquareSZ.ttf ProggySquareSZ > ../ProggySquareSZ.inl
binary_to_compressed_c ProggySquare.ttf ProggySquare > ../ProggySquare.inl
binary_to_compressed_c ProggyTinySZ.ttf ProggyTinySZ > ../ProggyTinySZ.inl
binary_to_compressed_c ProggyTiny.ttf ProggyTiny > ../ProggyTiny.inl
