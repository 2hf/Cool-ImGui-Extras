# KeyAuth-ImGui-Example
KeyAuth ImGui Example

- Download Repository
- Download the DirectX SDK.
- Download Visual studio 2019(V142 build tools)

Then you're ready to compile!

**What is KeyAuth?**

KeyAuth is an Open source authentication system with cloud hosting plans as well. Client SDKs available for C++, C#, Python, Rust, PHP, and VB.NET.
KeyAuth several unique features such as memory streaming, webhook function where you can send requests to API without leaking the API, discord webhook notifications, ban the user securely through the application at your discretion.
Feel free to join https://keyauth.com/discord/ if you have questions or suggestions.

2022-2-19 Fixed KeyAuth Url      
Thank you wnelson03!

2022-2-20 Supports the latest KeyAuth Update

2022-2-21 Added login error handling

2022-2-22 Added console hiding(By default, the console is not executed, but by executing it once and hiding the console, the subsequent processing on the console will be invisible.)

thank you lucentss!
