/*
* This file is subject to the terms and conditions defined in
* file 'LICENSE', which is part of this source code package.
*/

#pragma once
#define VERSION_SHORT_STRING "0.1.0.24"
#define VERSION_LONG_STRING "0.1.0.24-g0c7964c"
