usage :

copy this directory to under module's directory

ex)
c:/test/test_mod.dll

then

c:/test/scripts/script.json
...
c:/test/scripts/render.json
