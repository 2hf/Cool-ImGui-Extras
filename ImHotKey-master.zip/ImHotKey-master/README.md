# ImHotKey
Single Header Hotkey editor for dear imgui:

Edit and handle HotKeys

![Image of imHotKey](https://github.com/CedricGuillemet/ImHotKey/raw/master/ImHotKey.png)
