mkdir build-osx
cd build-osx
cmake ..
make

