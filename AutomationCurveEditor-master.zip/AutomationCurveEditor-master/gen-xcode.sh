mkdir xcode
cd xcode
cmake .. -G Xcode

